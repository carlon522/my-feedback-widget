// feedbackWidget.js – v1.5  (bookmarklet‑ready, duplicate‑proof)
// ---------------------------------------------------------------------------
//  ✱ Annotate *any* webpage – even sites you don’t own – by injecting this
//    script via a bookmarklet or browser‑extension.
//  ✱ Adds a guard so multiple injections don’t spawn duplicate buttons.
//  ✱ Keeps the Navigate ↔ Markup toggle and Firestore persistence.
// ---------------------------------------------------------------------------
(function () {
  // ... (full code from canvas) ...
})();